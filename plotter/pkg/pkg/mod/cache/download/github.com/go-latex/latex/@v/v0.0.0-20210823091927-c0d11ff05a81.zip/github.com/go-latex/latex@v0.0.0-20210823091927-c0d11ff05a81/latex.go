// Copyright ©2020 The go-latex Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package latex provides types and functions to work with LaTeX.
package latex // import "github.com/go-latex/latex"
