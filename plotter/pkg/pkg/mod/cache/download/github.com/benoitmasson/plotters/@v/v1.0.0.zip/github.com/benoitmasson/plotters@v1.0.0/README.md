# plot

Custom plotters for [github.com/gonum/plot](https://github.com/gonum/plot) package.

* [Pie chart](https://github.com/benoitmasson/plotters/tree/master/piechart)
