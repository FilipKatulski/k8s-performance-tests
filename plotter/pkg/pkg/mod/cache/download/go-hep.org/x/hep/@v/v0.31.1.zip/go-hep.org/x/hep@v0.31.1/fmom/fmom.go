// Copyright ©2017 The go-hep Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package fmom provides types and functions to operate with Lorentz 4-vectors.
package fmom // import "go-hep.org/x/hep/fmom"
