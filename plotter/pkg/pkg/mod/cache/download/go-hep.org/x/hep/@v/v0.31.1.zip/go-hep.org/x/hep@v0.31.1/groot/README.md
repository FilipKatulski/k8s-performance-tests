# groot

[![GoDoc](https://godoc.org/go-hep.org/x/hep/groot?status.svg)](https://godoc.org/go-hep.org/x/hep/groot)

Experimental, pure-Go package to read and write ROOT files, without having ROOT installed.

## Installation

```sh
go get go-hep.org/x/hep/groot
```

## Documentation

``groot`` documentation can be found over there:

https://godoc.org/go-hep.org/x/hep/groot
