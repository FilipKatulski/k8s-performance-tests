// Copyright ©2017 The go-hep Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// package predicates handles the geometric predicates for a delaunay triangulation
package predicates
