fmom
====

[![GoDoc](https://godoc.org/go-hep.org/x/hep/fmom?status.svg)](https://godoc.org/go-hep.org/x/hep/fmom)

`fmom` provides facilities to create and manipulate Lorentz 4-vectors.

## Installation

Is done with `go get`:

```sh
$ go get go-hep.org/x/hep/fmom
```

## Documentation

Is provided via `godoc`:

  https://godoc.org/go-hep.org/x/hep/fmom

