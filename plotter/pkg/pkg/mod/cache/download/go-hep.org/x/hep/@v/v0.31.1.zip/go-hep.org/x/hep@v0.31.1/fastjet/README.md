fastjet
=======

[![GoDoc](https://godoc.org/go-hep.org/x/hep/fastjet?status.svg)](https://godoc.org/go-hep.org/x/hep/fastjet)

Simple `Go`-based implementation of the `C++` `FastJet` library.
