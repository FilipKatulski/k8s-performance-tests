brio
====

`brio` is a library and a code generator for Binary I/O.
