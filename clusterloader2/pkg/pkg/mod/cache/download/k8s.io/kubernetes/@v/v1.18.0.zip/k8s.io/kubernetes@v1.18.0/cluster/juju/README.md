# Juju Provider

Source for charms and bundles related to Juju have moved to the
[Charmed Kubernetes][cdk-repo] GitHub organization. This directory will be
removed in a future release.

[cdk-repo]: https://github.com/charmed-kubernetes
